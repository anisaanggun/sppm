<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">

    </div>
    <!-- Default to the left -->
    <div class="mr-5" style="text-align: right;">
        <strong>Copyright &copy; 2024 <a href="" style="text-decoration:none;">pantaumesin</a>.</strong> All rights
        reserved.
    </div>

</footer>
<?php /**PATH C:\Users\USER\sppm\resources\views/admin/footer.blade.php ENDPATH**/ ?>