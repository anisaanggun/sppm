<?php $__env->startSection('contents'); ?>
    <div class="d-flex justify-content-center align-items-center vh-100" style="padding-top: 5px;">
        <div class="card shadow p-3 mb-5 bg-body-tertiary"
            style="overflow-y:auto; border: 2px solid #1E56A0; border-radius:15px !important;">

            
            <div style="text-align:center; padding: 20px;">
                <img src="/img/Logo.png" alt="" style="width: 50px; height:auto; margin-top:5px;">
                <b>
                    <p style="color: #1E56A0;">Masuk</p>
                </b>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <form action="<?php echo e(route('dologin')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">

                                

                                <input type="text" name="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email"
                                    aria-label="email" id="email" style="border-radius: 8px;">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">

                                

                                <input type="password" name="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password"
                                    aria-label="password" id="password" style="border-radius: 8px;">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-grid gap-2" style="margin-top: 20px;">
                                <button type="submit" class="btn"
                                    style="border-radius: 25px; background-color: #1E56A0; color: white; border: none;">Masuk</button>
                            </div>

                            <div style="margin-top: 20px; text-align:center;">
                                <p>
                                    Belum mempunyai akun?<b><a href="<?php echo e(route('daftar')); ?>">Daftar</a></b>
                                </p>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\sppm\resources\views/auth/login.blade.php ENDPATH**/ ?>